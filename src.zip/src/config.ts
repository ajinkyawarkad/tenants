export const firebaseConfig = {
    fire :{

        apiKey: "AIzaSyCjyUitM7_l2cTLnHSndXLI5DyLW1hayzs",
        authDomain: "adminnew-d710c.firebaseapp.com",
        projectId: "adminnew-d710c",
        storageBucket: "adminnew-d710c.appspot.com",
        messagingSenderId: "1017760632379",
        appId: "1:1017760632379:web:6048353cb4ac36aa6b961e",
        measurementId: "G-25WDLRTM3D"
        

        //  apiKey: "AIzaSyALh0_RQqpQWHXFe6hS-ojWftaY3-aopTQ",
        // authDomain: "adminsale-93b98.firebaseapp.com",
        // projectId: "adminsale-93b98",
        // storageBucket: "adminsale-93b98.appspot.com",
        // messagingSenderId: "242169418061",
        // appId: "1:242169418061:web:46b8ddbce7ace3bbfe6704",
        // measurementId: "G-M8M7QBJB54"

        // apiKey: "AIzaSyBM-6dwWsAm92iqBFU_Vy-WgLfVGZpdLqk",
        // authDomain: "newa-83e03.firebaseapp.com",
        // projectId: "newa-83e03",
        // storageBucket: "newa-83e03.appspot.com",
        // messagingSenderId: "482208305137",
        // appId: "1:482208305137:web:e91d17765a4c45c3797e50",
        // measurementId: "G-JH0CJ8XGNZ"
    }

   

}